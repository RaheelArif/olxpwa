module.exports = {
  port: process.env.PORT || 5002,
  saltRounds: 10,
  redirect: '/login',
}