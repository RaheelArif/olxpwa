import jquery from 'jquery'; // eslint-disable-line no-unused-vars
import '../../assets/js/popper.min.js';
import '../../assets/js/bootstrap.bundle.min.js';