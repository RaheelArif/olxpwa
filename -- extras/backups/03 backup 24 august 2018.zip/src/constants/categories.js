const categories = ['Mobiles', 'Laptops', 'Clothes', 'Vehicles', 'Accessories'];
module.exports = categories;