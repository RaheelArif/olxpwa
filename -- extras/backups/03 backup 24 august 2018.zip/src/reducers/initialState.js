export default {
  ads: [],
  myAdsListings: [],
  myMessages: [],
  catCounts: {},
}