import registrationLogic from './registrationLogic';
import loginLogic from './loginLogic';

export default [
  ...registrationLogic,
  ...loginLogic,
];