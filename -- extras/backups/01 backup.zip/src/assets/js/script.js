// import $ from 'jquery';
// $(document).ready(function(){
//   setTimeout(() => {
//     $('body').niceScroll();
//   }, 1000);
// });