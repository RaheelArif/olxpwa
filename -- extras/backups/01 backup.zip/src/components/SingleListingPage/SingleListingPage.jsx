import React from 'react';
import { Link } from 'react-router-dom';
import Lightbox from 'react-image-lightbox';

const SingleListingPage = (props) => {
  const { state, toggleLightbox, next, previous } = props;
  // const { state } = props;
  const { photoIndex, isOpen } = state;

  const listingTitle = "Moto Ext1022 (exchange possible good set)";
  const adCity = "Faisalabad";
  const adTime = "06:56 am";
  const adID = "861008364";
  const listingImage1 = require('../../assets/img/listing-image.jpg');
  const listingImage2 = require('../../assets/img/listing-image-2.jpg');
  const listingImage3 = require('../../assets/img/listing-image-3.jpg');
  const listingImage4 = require('../../assets/img/listing-image-4.jpg');
  const images = [
    listingImage1,
    listingImage2,
    listingImage3,
    listingImage4,
  ];

  const listingImagesThumbnails = images.map((image, index) => {
    return (
      <div key={index} className="single-listing-thumbnail">
        <img
          className="img-fluid"
          src={image}
          alt={`listing image 2`}
          onClick={() => toggleLightbox(index)}
        />
      </div>
    );
  });

  return (
    <div className="container">
      <div className="single-listing-breadcrumb">
        <Link to="/"><i className="fa fa-home"></i> Home</Link>
        <span className="breadcrumb-separator">/</span>
        <Link to="category">Category</Link>
        <span className="breadcrumb-separator">/</span>
        {`Complete listing name`}
      </div>

      <div className="single-listing-container">
        <div className="single-listing-title">
          <h2>{listingTitle}</h2>
          <div className="single-listing-metadata">
            <ul className="list-inline">
              <li className="list-inline-item"><i className="fa fa-map-pin"></i> {adCity}</li>
              <li className="list-inline-item"><span className="text-muted">|</span></li>
              <li className="list-inline-item"><i className="fa fa-clock-o"></i> added at {adTime}</li>
              <li className="list-inline-item">Ad ID: {adID}</li>
            </ul>
          </div>

          <div className="divider"></div>

          <div className="single-listing-item-image-container">
            <img className="img-fluid" onClick={toggleLightbox} src={listingImage1} alt={listingTitle} />
          </div>

          <div className="divider"></div>

          <div className="single-listing-thumbnails">
            {listingImagesThumbnails}
          </div>

          {/* Lightbox implementation for larger view of the images */}
          {isOpen && (
            <Lightbox
              mainSrc={images[photoIndex]}
              nextSrc={images[(photoIndex + 1) % images.length]}
              prevSrc={images[(photoIndex + images.length - 1) % images.length]}
              onCloseRequest={() => toggleLightbox(0)}
              onMovePrevRequest={() => { previous(images) }}
              onMoveNextRequest={() => { next(images) }}
            />
          )}

          <div className="divider"></div>

          <div className="single-listing-details">
            <div className="single-listing-metadata">
              <div className="single-listing-item-brand">

              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};

export default SingleListingPage;
