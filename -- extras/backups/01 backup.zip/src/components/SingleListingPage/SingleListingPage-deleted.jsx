import React from 'react';
import {Link} from 'react-router-dom';
import Lightbox from 'react-images';

const SingleListingPage = (props) => {
  const {state, toggleLightbox, next, previous} = props;

  const listingTitle = "Moto Ext1022 (exchange possible good set)";
  const adCity = "Faisalabad";
  const adTime = "06:56 am";
  const adID = "861008364";
  const listingImage1 = require('../../assets/img/listing-image.jpg');
  const listingImage2 = require('../../assets/img/listing-image-2.jpg');
  const listingImage3 = require('../../assets/img/listing-image-3.jpg');
  const listingImage4 = require('../../assets/img/listing-image-4.jpg');
  return(
    <div className="container">
      <div className="single-listing-breadcrumb">
        <Link to="/"><i className="fa fa-home"></i> Home</Link>
        <span className="breadcrumb-separator">/</span>
        <Link to="category">Category</Link>
        <span className="breadcrumb-separator">/</span>
        {`Complete listing name`}
      </div>

      <div className="single-listing-container">
        <div className="single-listing-title">
          <h2>{listingTitle}</h2>
          <div className="listing-metadata">
            <ul className="list-inline">
              <li className="list-inline-item"><i className="fa fa-map-pin"></i> {adCity}</li>
              <li className="list-inline-item"><span className="text-muted">|</span></li>
              <li className="list-inline-item"><i className="fa fa-clock-o"></i> added at {adTime}, Add ID: {adID}</li>
            </ul>
          </div>

          <div className="divider"></div>

          <div className="single-listing-item-image-container">
            <img className="img-fluid" onClick={toggleLightbox} src={require('../../assets/img/listing-image.jpg')} alt={listingTitle} />
          </div>
          <div className="row single-listing-thumbnails">
            <div className="col-6 col-sm-4 col-md-3 col-lg-2 col-xl-1 single-listing-thumbnail">
              <img className="img-fluid" src={listingImage2} alt={`listing image 2`} />
            </div>
            <div className="col-6 col-sm-4 col-md-3 col-lg-2 col-xl-1 single-listing-thumbnail">
              <img className="img-fluid" src={listingImage3} alt={`listing image 2`} />
            </div>
            <div className="col-6 col-sm-4 col-md-3 col-lg-2 col-xl-1 single-listing-thumbnail">
              <img className="img-fluid" src={listingImage4} alt={`listing image 2`} />
            </div>
            <div className="col-6 col-sm-4 col-md-3 col-lg-2 col-xl-1 single-listing-thumbnail">
              <img className="img-fluid" src={listingImage1} alt={`listing image 2`} />
            </div>
          </div>

          <Lightbox
            images={[
              { src: listingImage2 },
              { src: listingImage1 },
              { src: listingImage3 },
              { src: listingImage4 },
            ]}
            isOpen={state.lightboxIsOpen}
            currentImage={state.activeIndex}
            onClickPrev={() => {previous()}}
            onClickNext={() => {next()}}
            onClose={toggleLightbox}
            showThumbnails={true}
            onClickThumbnail={() => console.log('image clicked')}
            onClickImage={() => console.log('image clicked')}
          />
        </div>
      </div>
    </div>
  );
};

export default SingleListingPage;
