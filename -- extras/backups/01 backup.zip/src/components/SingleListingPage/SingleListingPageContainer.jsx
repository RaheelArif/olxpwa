import React, { Component } from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import SingleListingPage from './SingleListingPage';
class SingleListingPageContainer extends Component {
  state = {
    photoIndex: 0,
    isOpen: false,
  }

  toggleLightbox = (photoIndex) => {
    if(!isNaN(Number(photoIndex))){
      this.setState({ photoIndex: photoIndex });
    }
    this.setState({ isOpen: !this.state.isOpen });
  };

  next = (images) => {
    let photoIndex = this.state.photoIndex;
    this.setState({
      photoIndex: (photoIndex + 1) % images.length,
    })
  };

  previous = (images) => {
    let photoIndex = this.state.photoIndex;
    this.setState({
      photoIndex: (photoIndex + images.length - 1) % images.length,
    });
  }

  render() {
    return (
      <SingleListingPage
        state={this.state}
        toggleLightbox={this.toggleLightbox}
        next={this.next}
        previous={this.previous}
      />
    );
  }
}

SingleListingPageContainer.propTypes = {
  // myProp: PropTypes.string.isRequired
}

function mapStateToProps(state, ownProps) {
  return {
    state: state
  }
}

function mapDispatchToProps(dispatch) {
  return {
    // actions: bindActionCreators(actions, dipatch)
  };
}


export default connect(mapStateToProps, mapDispatchToProps)(SingleListingPageContainer);
