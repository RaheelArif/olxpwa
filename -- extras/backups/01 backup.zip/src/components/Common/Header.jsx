import React, { Component } from 'react';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import { withRouter, NavLink, Link } from 'react-router-dom';
// import RegisterPage from "../RegisterPage/RegisterPageContainer";
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import * as loginActions from '../../actions/LoginActions';
import olxLogo from '../../assets/img/olx-logo.png';
// import LoginPage from '../LoginPage/LoginPageContainer';
// import SelectRegisterType from '../RegisterPage/SelectRegisterType';
import $ from 'jquery';

class Header extends Component {
  state = {
    registerDialogOpen: false,
    loginDialogOpen: false,
    authenticated: this.props.authenticated,
  };

  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.authenticated != this.state.authenticated) {
  //     this.setState({ authenticated: nextProps.authenticated });
  //     this.handleLoginClose();
  //     this.props.history.push('/');
  //   }
  // }

  // handleLoginOpen = () => {
  //   this.setState({ loginDialogOpen: true });
  //   setTimeout(() => {
  //     $('.registration-form').niceScroll();
  //   }, 50);
  // };

  // handleLoginClose = () => {
  //   $('.login-form').hide(); // avoids flashing the scroller at closing of dialog
  //   this.setState({ loginDialogOpen: false });
  // };

  // handleLogout = () => {
  //   this.props.actions.logout();
  // }

  render() {

    const loginActions = [
      <FlatButton
        label="Cancel"
        primary={true}
        onClick={this.handleLoginClose}
        key={1}
      />
    ];
    return (
      <header>
        <div className="container">
          <div className="row pt-2 pb-2">
            <div className="col-12 col-md-6 d-flex">
              <div className="site-logo">
                <img className="m-auto img-fluid" src={olxLogo} alt={`OLX Pakistan`} />
              </div>
              <div className="site-slogan">
                <span className="m-auto bold">{`Pakistan's Largest Marketplace`}</span>
              </div>
            </div>
            <div className="col-12 col-md-6 m-auto text-right">
                <a className="btn btn-custom-hollow" href="#"><i className="fa fa-user"></i> My Account</a>
                <a className="btn btn-custom-orange mr-0" href="#">Post an Ad</a>
            </div>
          </div>
          {/*
          <nav className="navbar navbar-expand-md navbar-light">
            <a className="navbar-brand" href="#"><img className="img-fluid" src={olxLogo} alt={`OLX Pakistan`} /></a>
            <span className="bold d-none d-md-flex">{`Pakistan's Largest Marketplace`}</span>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav ml-auto">
                <li className="nav-item d-none d-md-flex">
                  <a className="btn btn-custom-hollow" href="#"><i className="fa fa-user"></i> My Account</a>
                </li>
                <li className="nav-item d-none d-md-flex">
                  <a className="btn btn-custom-orange" href="#">Post an Ad</a>
                </li>
                <li className="nav-item d-sm-flex d-md-none">
                  <a className="nav-link" href="#">My Account <i className="fa fa-user"></i></a>
                </li>
                <li className="nav-item d-sm-flex d-md-none">
                  <a className="nav-link" href="#">Post an Ad</a>
                </li>
              </ul>
            </div>
          </nav>
          */}
        </div>

        {/* <Dialog
          // title="Login Form"
          actions={loginActions}
          modal={false}
          open={this.state.loginDialogOpen}
          onRequestClose={this.handleLoginClose}
          autoScrollBodyContent={true}
          bodyClassName="login-form"
        >
          <LoginPage />
        </Dialog> */}
      </header>
    );
  }
}

Header.propTypes = {
  actions: PropTypes.object.isRequired,
  authenticated: PropTypes.bool.isRequired,
  user: PropTypes.object.isRequired,
  history: PropTypes.object.isRequired
}

const mapStateToProps = (state, ownProps) => {
  return {
    authenticated: state.session.authenticated,
    user: state.session.user
  }
}

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    actions: bindActionCreators(loginActions, dispatch)
  }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Header));