import React from 'react';
import itemLogo from '../../assets/img/listing-image.jpg';

const AllAds = (props) => {
  const title = "Everything Else";
  const description = "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Maxime natus expedita atque odit doloremque voluptates cum inventore. Iste aperiam quis fuga non. Vitae perspiciatis rem cum doloremque magnam commodi exercitationem?";
  const category = "Mobiles";
  const listings = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  const adsListings = listings.map((listings, index) => {
    return (
      <div key={index} className="all-listings-single-listing border">
        <div className="row mr-0 ml-0">
          <div className="col-12 col-sm-3 single-listing-img-container">
            <img className="img-fluid" src={itemLogo} alt={`item title`} />
          </div>
          <div className="col-12 col-sm-9 single-listing-description-container">
            <div className="item-title">
              <h3>Item Title is here</h3>
              <p>
                Category: {category}
              </p>
              <div className="row bottom">
                <div className="col-9">
                  <span className="price">Rs. 1,01,000</span>
                </div>
                <div className="col-3 text-right">
                  <a href="#"><i title="save to view later" className="fa fa-clock-o"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  })
  return (
    <div className="block all-ads">
      <h2 className="mb-0">{title}</h2>
      <span className="text-muted">We found 1,80,295 items</span>
      <div className="all-listings">

        {adsListings}

      </div>
    </div>
  );
};

export default AllAds;
