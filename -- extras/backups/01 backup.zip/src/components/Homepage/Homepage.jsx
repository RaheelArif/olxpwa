import React from 'react';
import {Link} from 'react-router-dom';
import FeaturedAds from '../FeaturedAds/FeaturedAdsContainer';
import AllAds from '../AllAds/AllAdsContainer';
import PostYourAd from '../Common/PostYourAd';
const Homepage = () => {
  return (
    <div className="container">
      <div className="block ads-search-fields">
        <div className="row">
          <div className="col-12 col-md-6">
            <label htmlFor="categories">Browse Categories</label>
            <select name="categories" id="categories" className="form-control">
              <option value="category">Select Category</option>
              <option value="something">something</option>
            </select>
          </div>
          <div className="col-12 col-md-6">
            <label htmlFor="search">Search for a specific product</label>
            <input type="text" name="search" className="form-control" placeholder="e.g samsung galaxy, tv" />
          </div>
        </div>
      </div>

      <div className="block ads-categories-block">
        <ul className="categories-list">
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
          <li><a href="#">Category Name</a> <span className="text-muted">(13,000)</span></li>
        </ul>
      </div>

      <div className="block">
        <div className="bread-crumb">
          <a href="#"><i className="fa fa-home"></i> Home</a> »
        {` Pakistan's featured Classifieds`}
        </div>
      </div>

      <FeaturedAds />
      <AllAds />
      <PostYourAd />
    </div>
  );
};
Homepage.defaultProps = {
  // someProp: 'Some Value',
}

Homepage.propTypes = {
  // someValue: PropTypes.string,
}

export default Homepage;
