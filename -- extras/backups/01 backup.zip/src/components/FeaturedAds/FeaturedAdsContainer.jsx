import React, { Component } from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import FeaturedAds from './FeaturedAds';
class FeaturedAdsContainer extends Component {
  state = {

  }

  render() {
    return(
      <FeaturedAds />
    );
  }
}

FeaturedAdsContainer.propTypes = {
  // myProp: PropTypes.string.isRequired
}

function mapStateToProps(state, ownProps) {
  return {
    // state: state
  }
}

function mapDispatchToProps(dispatch) {
  return {
    // actions: bindActionCreators(actions, dipatch)
  };
}


export default connect(mapStateToProps, mapDispatchToProps)(FeaturedAdsContainer);
