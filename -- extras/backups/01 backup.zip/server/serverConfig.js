module.exports = {
  port: process.env.PORT || 5000,
  saltRounds: 10,
  redirect: '/login',
}