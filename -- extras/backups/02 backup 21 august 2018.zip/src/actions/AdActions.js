import * as types from '../constants/constants';

export function submitAd(ad) {
  return {
    type: types.SUBMIT_AD,
    payload: ad
  }
}

export function loadAllAds() {
  return {
    type: types.LOAD_ALL_ADS,
  }
}

export function loadAllAdsSuccess(ads) {
  return {
    type: types.LOAD_ALL_ADS_SUCCESS,
    payload: ads
  }
}

export function searchAds(query) {
  return {
    type: types.SEARCH_ADS,
    payload: query
  }
}

export function filterAds(filter) {
  return {
    type: types.FILTER_ADS,
    payload: filter
  }
}