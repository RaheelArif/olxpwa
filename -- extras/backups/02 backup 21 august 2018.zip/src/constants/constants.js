// settings for front end
// export const API_URL = "http://localhost:5000/";
export const API_URL = "http://localhost:5002/";
export const allowedTitleChars = 105;

// USER ACTIONS
export const LOGIN_USER = "LOGIN_USER";
export const LOGIN_USER_SUCCESS = "LOGIN_USER_SUCCESS";
export const LOGIN_USER_FAILED = "LOGIN_USER_FAILED";

// AD ACTIONS
export const SUBMIT_AD = "SUBMIT_AD";
export const SUBMIT_AD_SUCCESS = "SUBMIT_AD_SUCCESS";
export const SUBMIT_AD_FAILED = "SUBMIT_AD_FAILED";

// AD ACTIONS
export const SEARCH_ADS = "SEARCH_ADS";
export const SEARCH_ADS_SUCCESS = "SEARCH_ADS_SUCCESS";

export const FILTER_ADS = "FILTER_ADS";
export const FILTER_ADS_SUCCESS = "FILTER_ADS_SUCCESS";

export const LOAD_ALL_ADS = "LOAD_ALL_ADS";
export const LOAD_ALL_ADS_SUCCESS = "LOAD_ALL_ADS_SUCCESS";
export const LOAD_ALL_ADS_FAILED = "LOAD_ALL_ADS_FAILED";

export const REGISTER_USER = "REGISTER_USER";
export const REGISTER_USER_SUCCESS = "REGISTER_USER_SUCCESS";
export const REGISTER_USER_FAILED = "REGISTER_USER_FAILED";

export const LOGOUT = "LOGOUT";
export const LOGOUT_SUCCESS = "LOGOUT_SUCCESS";