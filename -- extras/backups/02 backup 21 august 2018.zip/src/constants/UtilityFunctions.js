import React from 'react'; // since we are using the jsx to return, so necessary to import React here.
import MenuItem from 'material-ui/MenuItem';
import axios from 'axios';
import { API_URL } from "../constants/constants";
import toastr from 'toastr';

// later, this will be fetched from database, but for now, lets hard-code them.
const categories = ['Mobiles', 'Laptops', 'Clothes', 'Vehicles', 'Accessories'];
// import objectAssign from 'object-assign';
const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const UtilityFunctions = {

  getCategoriesDropdownList: function () {
    const categoryList = categories.map((category, index) => {
      return <MenuItem key={index} value={category} primaryText={category} />
    });
    return categoryList;
  },

  getCategories: function () {
    return categories;
  },

  getAdById: function (allAds, id) {
    return allAds.filter((ad) => ad._id == id)[0];
  },

  getAdByIdFromServer: function (id) {
    return new Promise(function (resolve, reject) {
      axios.post(`${API_URL}ads/getAdById`, {
        adId: id
      })
        .then(resp => {
          console.log(resp.data);
          // return resp.data;
          resolve(resp.data);
        }).catch(err => {
          toastr.error(err);
          reject(err);
        })
    });
  },
  /*
    getAdByIdSync: async function(allAds, id) {

      return await new Promise(function(resolve, reject) {
        let ad = allAds.filter((ad) => ad._id == id)[0];
        if(!ad) {
          // console.log('obtaining ad from server');
          // return {uploader: { createdAt: "August 1, 2018" }, createdAt: "August 1, 2018"};
          axios.post(`${API_URL}ads/getAdById`, {
            adId: id
          })
          .then(resp => {
            console.log(resp.data);
            // return resp.data;
            resolve(resp.data);
          }).catch(err => {
            toastr.error(err);
            reject(err);
          })
        } else {
          resolve(ad);
        }
      });

    },
  */
  getDateTime: function (date) {
    let month = months[date.getMonth()];
    let hours = date.getHours();
    let minutes = date.getMinutes();
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    let ampm = (hours < 12) ? "am" : "pm";
    let hoursToDisplay = (hours % 12 === 0) ? 12 : hours % 12;
    let dateTime = `${month} ${date.getDate()}, ${date.getFullYear()} ${hoursToDisplay}:${minutes} ${ampm}`;
    return dateTime;
  },

  getDate: function (date) {
    let month = months[date.getMonth()];
    let dateTime = `${month} ${date.getDate()}, ${date.getFullYear()}`;
    return dateTime;
  }
  /*
    getRequirementList: function(requirementsArray) {
      const requirements = requirementsArray.map((requirement, index) => {
        return requirement.trim().length > 0 ? <li key={index}>{requirement}</li>: null
      });
      return requirements;
    },
  */
};

export default UtilityFunctions;