import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import allAdsReducer from './allAdsReducer';
// import people from "./peopleReducer";
// import registrations from "./registrationReducer";
// import loggedInUser from './loginReducer';
// import myListingReducer from './myListingReducer';
// import donorListingReducer from './donorListingReducer';
// import adminReducer from './adminReducer';
import { sessionReducer } from 'redux-react-session';

const rootReducer = combineReducers({
  routing: routerReducer,
  session: sessionReducer,
  allAds: allAdsReducer
});

export default rootReducer;