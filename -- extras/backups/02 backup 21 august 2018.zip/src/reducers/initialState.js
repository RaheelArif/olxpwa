export default {
  ads: [],
}