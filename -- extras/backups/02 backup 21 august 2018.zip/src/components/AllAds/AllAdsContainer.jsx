import React, { Component } from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import * as adActions from '../../actions/AdActions';
import AllAds from './AllAds';
class AllAdsContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      allAds: props.allAds ? props.allAds : [],
    }
    props.actions.loadAllAds();
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if( nextProps.allAds ) {
      return { allAds: nextProps.allAds }
    }
    return null;
  }

  render() {
    return(
      <AllAds
        allAds={this.state.allAds}
        filterCategory={this.props.filterCategory}
      />
    );
  }
}
AllAdsContainer.defaultProps = {
  filterCategory: 'All'
}

AllAdsContainer.propTypes = {
  // myProp: PropTypes.string.isRequired
  filterCategory: PropTypes.string
}

function mapStateToProps(state, ownProps) {
  return {
    allAds: state.allAds,
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(adActions, dispatch)
  };
}


export default connect(mapStateToProps, mapDispatchToProps)(AllAdsContainer);
