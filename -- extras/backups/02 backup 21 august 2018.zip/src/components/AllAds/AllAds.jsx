import React from 'react';
// import itemLogo from '../../assets/img/listing-image.jpg';
import { Link } from "react-router-dom";
import { API_URL } from '../../constants/constants';
const AllAds = (props) => {
  const { allAds, filterCategory } = props;
  const title = `Displaying ${filterCategory ? filterCategory : `All`} ads`;
  const adsListings = allAds.slice(0, 10).map((ad, index) => {
    return (
      <div key={index} className="all-listings-single-listing border">
        <div className="row mr-0 ml-0">
          <div className="col-12 col-sm-3 single-listing-img-container">
            <Link to={`/item/${ad._id}`}><img className="img-fluid" src={`${API_URL}image/${ad.images[0]}`} alt={ad.title} /></Link>
          </div>
          <div className="col-12 col-sm-9 single-listing-description-container">
            <div className="item-title">
              <h3><Link to={`/item/${ad._id}`}>{ad.title}</Link></h3>
              <p>
                Category: {ad.category}
              </p>
              <div className="row bottom">
                <div className="col-9">
                  <span className="price">Rs. {ad.price}</span>
                </div>
                <div className="col-3 text-right">
                  <a href="#"><i title="save to view later" className="fa fa-clock-o"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  })
  return (
    <div className="block all-ads">
      <h2 className="mb-0">{title}</h2>
      <span className="text-muted">We found {allAds.length} items</span>
      <div className="all-listings">
        {adsListings}
      </div>
    </div>
  );
};

export default AllAds;
