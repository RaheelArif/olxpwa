import React, { Component } from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import Homepage from './Homepage';
import * as adActions from '../../actions/AdActions';
// import $ from 'jquery';
class HomepageContainer extends Component {
  state = {
    category: '',
  }

  handleCategoryChange = (e, child) => {
    this.setState(
      { category: e.target.value },
      () => { this.props.actions.filterAds({ category: e.target.value }) }
    );
  };

  render() {
    return (
      <Homepage
        state={this.state} handleCategoryChange={this.handleCategoryChange}
      />
    );
  }
}

HomepageContainer.propTypes = {
  // myProp: PropTypes.string.isRequired
  allAds: PropTypes.array
}

function mapStateToProps(state, ownProps) {
  return {
    // someValue: state.someValue,
    allAds: state.allAds
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(adActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(HomepageContainer);
