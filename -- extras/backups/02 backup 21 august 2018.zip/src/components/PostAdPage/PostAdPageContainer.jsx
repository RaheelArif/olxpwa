import React, { Component } from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import {bindActionCreators} from 'redux';
import * as adActions from '../../actions/AdActions';
import PostAdForm from './PostAdForm';

class PostAdPageContainer extends Component {
  // state = {
  //   ad: resetAd(),
  //   errors: resetAd(),
  //   validateOnChange: false,
  // };
  constructor(props) {
    super(props);
    this.state = {
      authenticated: props.authenticated,
      allAds: props.allAds
    };
    if(!props.authenticated) {
      props.history.push('/login');
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if(nextProps.authenticated != prevState.authenticated) {
      return { authenticated: nextProps.authenticated }
    }
    return null;
  }

  componentDidUpdate(prevProps, prevState) {
    if(!this.state.authenticated) {
      this.props.history.push('/login');
    }
  }

  render() {
    return(
      <PostAdForm />
    );
  }
}

PostAdPageContainer.propTypes = {
  // myProp: PropTypes.string.isRequired
}

function mapStateToProps(state, ownProps) {
  return {
    authenticated: state.session.authenticated,
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(adActions, dispatch)
  };
}


export default connect(mapStateToProps, mapDispatchToProps)(PostAdPageContainer);
