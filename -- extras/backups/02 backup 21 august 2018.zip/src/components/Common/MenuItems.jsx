import React, { Component } from 'react';
import PropTypes from "prop-types";
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { withStyles } from '@material-ui/core/styles';
import { Link } from "react-router-dom";
// ------------
import MoreVert from '@material-ui/icons/MoreVert';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';
import ListSubheader from '@material-ui/core/ListSubheader';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Collapse from '@material-ui/core/Collapse';
import InboxIcon from '@material-ui/icons/MoveToInbox';
import DraftsIcon from '@material-ui/icons/Drafts';
import SendIcon from '@material-ui/icons/Send';
import PersonIcon from '@material-ui/icons/Person';
import LogoutIcon from '@material-ui/icons/SettingsPower';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';
import StarBorder from '@material-ui/icons/StarBorder';
// import AddIcon from '@material-ui/icons/Add';
import AddIcon from '@material-ui/icons/AddBoxRounded';
// ------------

const styles = theme => ({
  button: {
    margin: theme.spacing.unit,
  },
  list: {
    width: 250,
  },
  fullList: {
    width: 'auto',
  },
  root: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: theme.palette.background.paper,
  },
  nested: {
    paddingLeft: theme.spacing.unit * 4,
  },
});

class MenuItems extends Component {
  state = {
    authenticated: this.props.authenticated,
  }

  render() {
    const { classes, authenticated, handleLogout, toggleDrawer } = this.props;
    return (
      <div className={classes.root}>
        <List
          component="nav"
          className="drawer-list"
          // subheader={<ListSubheader component="div">Nested List Items</ListSubheader>}
        >
          <ListItem>
            <ListItemIcon>
              <SendIcon />
            </ListItemIcon>
            {/* <ListItemText inset primary="Sent mail" /> */}
            <Link to="/register" onClick={toggleDrawer(false)}>My Account</Link>
          </ListItem>

          {
          this.state.authenticated &&
          <ListItem>
            <ListItemIcon>
              <AddIcon />
            </ListItemIcon>
            {/* <ListItemText inset primary="Sent mail" /> */}
            <Link to="/post-your-ad" onClick={toggleDrawer(false)}>Post an Ad</Link>
          </ListItem>
          }

          {
          authenticated &&
          <ListItem>
            <ListItemIcon>
              <LogoutIcon />
            </ListItemIcon>
            <Link to="/#" onClick={() => {handleLogout(); toggleDrawer(false)}}>Logout</Link>
          </ListItem>
          }

          {
          !authenticated &&
          <ListItem>
            <ListItemIcon>
              <PersonIcon />
            </ListItemIcon>
            <Link to="/login" onClick={toggleDrawer(false)}>Login</Link>
          </ListItem>
          }

          {
            /* <ListItem button onClick={this.nestedListToggle}>
              <ListItemIcon>
                <InboxIcon />
              </ListItemIcon>
              <ListItemText inset primary="Inbox" />
              {this.state.nestedListOpen ? <ExpandLess /> : <ExpandMore />}
            </ListItem> */
          }

          {
            /* <Collapse in={this.state.nestedListOpen} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <ListItem button className={classes.nested}>
                  <ListItemIcon>
                    <StarBorder />
                  </ListItemIcon>
                  <ListItemText inset primary="Starred" />
                </ListItem>
              </List>
            </Collapse>
            */
          }
        </List>
      </div>
    );
  }
}

MenuItems.propTypes = {
  // myProp: PropTypes.string.isRequired
}

function mapStateToProps(state, ownProps) {
  return {
    // authenticated: state.session.authenticated,
  }
}

function mapDispatchToProps(dispatch) {
  return {
    // actions: bindActionCreators(actions, dispatch)
  };
}


export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(MenuItems));
