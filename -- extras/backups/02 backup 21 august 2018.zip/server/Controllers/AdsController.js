// const config = require('../serverConfig');

const Ad = require('../Models/Ad');
// const isAlphanumeric = require('validator/lib/isAlphanumeric');
// const isEmpty = require('validator/lib/isEmpty');
// const isNumeric = require('validator/lib/isNumeric');
// const isEmail = require('validator/lib/isEmail');
// const isAlpha = require('validator/lib/isAlpha');


const AdController = {
  createNewAd: function (ad, imgNames) {
    return new Promise(function (resolve, reject) {
      // promise api should be available. This will work properly only if promise api is available.
      if(imgNames.length < 1) {
        imgNames = ['430x275.png']; //default image
      }
      let newAd = new Ad();
      newAd.title = ad.adTitle;
      newAd.category = ad.category;
      newAd.model = ad.model;
      newAd.condition = ad.condition;
      newAd.price = ad.price
      newAd.description = ad.adDescription;
      newAd.uploader = ad.user;
      newAd.images = imgNames;
      newAd.sellerName = ad.sellerName;
      newAd.itemCity = ad.itemCity;
      newAd.sellerPhoneNumber = ad.sellerPhoneNumber;

      newAd.save(function (error, ad) {
        if (error) {
          reject({ message: 'Error in saving your ad, please make sure that you have provided the complete details.', error: error, ad: null });
        } else {
          resolve({ message: 'Ad saved', error: null, ad: ad });
        }
      });
    });
  },

  getAllAds: function () {
    return new Promise(function (resolve, reject) {
      let query = Ad.find();
      query.populate('uploader');
      query.exec(function (error, result) {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      })
    });
  },

  getAdById: function (adId) {
    return new Promise(function (resolve, reject) {
      let query = Ad.findById(adId);
      query.populate('uploader');
      query.exec(function (error, result) {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      })
    });
  },

  getMyListings: function (user) {
    return new Promise(function (resolve, reject) {
      let query = Listing.find({uploader: user.id});
      query.populate('uploader');
      query.exec(function (error, result) {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      })
    });
  },

  updateListing: function (listing, imgNames) {
    return new Promise(function (resolve, reject) {
      // promise api should be available. This will work properly only if promise api is available.
      let updatedListing = {};
      updatedListing.category = listing.category;
      updatedListing.title = listing.title;
      updatedListing.description = listing.description;
      updatedListing.requirements = JSON.parse(listing.requirements);
      updatedListing.estimatedCost = listing.estimatedCost;
      updatedListing.costRepeater = listing.costRepeater;
      updatedListing.uploader = listing.user;
      updatedListing.name = listing.name;
      updatedListing.address = listing.address;
      updatedListing.city = listing.city;
      updatedListing.phone = listing.phone;
      updatedListing.public = listing.public;
      updatedListing.cnicNumber = listing.cnicNumber;
      if(imgNames.length > 0) {
        updatedListing.img = imgNames;
      }
      Listing.findByIdAndUpdate(listing._id, updatedListing, {new: true}, function(error, listing) {
        if(error) {
          reject({status: 'error', error: error});
        }else{
          resolve({status: 'ok', message: 'Listing Updated', error: null, listing: listing});
        }
      });
    });
  },

  deleteListing: function(id) {
    return new Promise(function (resolve, reject) {
      Listing.deleteOne({_id: id}, function(error) {
        if(error) {
          reject({status: 'error', error: error});
        }else{
          resolve({status: 'ok', message: 'Listing Deleted', error: null});
        }
      });
    });
  },
  wannaHelp: function(listingInfo) {
    const listingId = listingInfo.listingId;
    const userId = listingInfo.userId;
    return new Promise(function (resolve, reject) {
      Listing.findOneAndUpdate({_id: listingId}, {$addToSet: {favorites: userId}}, function(error) {
        if(error) {
          reject({status: 'error', error: error});
        }else{
          resolve({status: 'ok', message: 'Listing added to your favored listing', error: null});
        }
      });
    });
  },
  getDonorListings: function (user) {
    return new Promise(function (resolve, reject) {
      let query = Listing.find({favorites: user.id});
      // query.populate('uploader');
      query.exec(function (error, result) {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      })
    });
  },
  deleteDonorListing: function(listingInfo) {
    const listingId = listingInfo.listingId;
    const userId = listingInfo.userId;
    return new Promise(function (resolve, reject) {
      Listing.findOneAndUpdate({_id: listingId}, { $pull: {favorites: userId} }, function(error) {
        if(error) {
          reject({status: 'error', error: error});
        } else {
          resolve({status: 'ok', message: 'Listing removed from favorites', error: null});
        }
      });
    });
  },

  filterAds: function (filters) {
    // let filter = listingInfo.filter;
    // let filterValue = listingInfo.filterValue;
    return new Promise(function (resolve, reject) {
      /*
       filter will be different each time so using its value
       i.e if filter = 'category' then query will be find 'category' = filterValue;
       thses brackets "[]" are the part of syntax if want to provide a value from variable.
       if I provide without "[]" brackets, it will search for a key of "filter" = "filterValue"
      */
      // let query = Ad.find({[filter]: filterValue});
      let query = Ad.find(filters);
      query.populate('uploader');
      query.exec(function (error, result) {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      })
    });
  },

  searchListings: function (searchFilter) {
    return new Promise(function (resolve, reject) {
      let query = Listing.find({$text: {$search: searchFilter}});
      query.populate('uploader');
      query.exec(function (error, result) {
        if (error) {
          reject(error);
        } else {
          resolve(result);
        }
      })
    });
  },
}

module.exports = AdController;